// Auth middleware to validate JWT signature from the request header and request generating from CB.

import express from 'express';
import jwt from 'jsonwebtoken';
import { Error401Exception } from '../exceptions/http.exception';
import moment from 'moment';

interface AuthenticationTokenPayload {
  url: string;
  body: string;
  iss: string;
  exp: number;
}

async function internalAuthMiddleware(
  request: express.Request,
  _response: express.Response,
  next: express.NextFunction
): Promise<void> {
  const internalToken =
    request.headers['X-INOVE-SIGNATURE'] ||
    request.headers['X-INOVE-SIGNATURE'.toLowerCase()];
  if (internalToken && typeof internalToken === 'string') {
    const secret = process.env.INOVE_SIGNATURE_SECRET || '';
    try {
      const verificationResponse = jwt.verify(
        internalToken,
        secret
      ) as AuthenticationTokenPayload;
      if (
        verificationResponse.iss === 'INOVE' &&
        verificationResponse.exp > moment().unix() &&
        verificationResponse.url === request.url &&
        (request.method === 'GET'
          ? JSON.stringify({})
          : JSON.stringify(request.body)) === verificationResponse.body
      ) {
        // Success
        next();
      } else {
        // Throw exception
        next(new Error401Exception());
      }
    } catch (error) {
      // Throw exception
      next(new Error401Exception());
    }
  } else {
    // Throw exception
    next(new Error401Exception());
  }
}

export default internalAuthMiddleware;