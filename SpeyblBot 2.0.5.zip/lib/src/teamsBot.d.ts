import { TeamsActivityHandler } from "botbuilder";
export declare class TeamsBot extends TeamsActivityHandler {
    constructor();
}
