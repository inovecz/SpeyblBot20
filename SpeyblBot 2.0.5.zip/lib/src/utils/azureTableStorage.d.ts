import { ConversationReference } from "botbuilder";
import { ConversationReferenceStore, ConversationReferenceStoreAddOptions, PagedData } from "@microsoft/teamsfx";
export declare class BlobStore implements ConversationReferenceStore {
    private readonly client;
    private initializePromise?;
    constructor(connectionString: string, containerName: string);
    /**
     * This implementation uses container URL and managed identity to connect Azure Blob Storage.
     * To use this, please follow the steps here (https://learn.microsoft.com/entra/identity-platform/multi-service-web-app-access-storage)
     * to enable managed identity and assign the necessary roles.
     *
     * @param containerUrl - the container URL, e.g. `https://<account>.blob.core.windows.net/<container>`
     */
    get(key: string): Promise<Partial<ConversationReference>>;
    add(key: string, reference: Partial<ConversationReference>, options?: ConversationReferenceStoreAddOptions): Promise<boolean>;
    remove(key: string, reference: Partial<ConversationReference>): Promise<boolean>;
    list(pageSize?: number, continuationToken?: string): Promise<PagedData<Partial<ConversationReference>>>;
    private initialize;
    private normalizeKey;
    private streamToBuffer;
}
