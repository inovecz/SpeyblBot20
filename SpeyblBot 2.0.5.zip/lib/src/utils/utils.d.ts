import NotificationPayload from '../interfaces/notificationPayload';
export declare const generateSignature: ({ url, body, }: {
    url: string;
    body: string;
}) => string;
export declare const prettyJSON: (data: unknown) => string;
export declare const generateAdaptiveCard: ({ notificationPayload }: {
    notificationPayload: NotificationPayload;
}) => any;
