import { BotBuilderCloudAdapter } from "@microsoft/teamsfx";
export declare const notificationApp: BotBuilderCloudAdapter.ConversationBot;
