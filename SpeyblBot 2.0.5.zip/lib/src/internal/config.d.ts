declare const config: {
    MicrosoftAppId: string;
    MicrosoftAppType: string;
    MicrosoftAppTenantId: string;
    MicrosoftAppPassword: string;
    BlobStorageConnectionString: string;
    BlobStorageContainerName: string;
};
export default config;
