declare class HttpException extends Error {
    status: number;
    message: string;
    constructor(status: number, message: string);
}
export declare class Error401Exception extends HttpException {
    constructor();
}
export default HttpException;
