import express from 'express';
declare function internalAuthMiddleware(request: express.Request, _response: express.Response, next: express.NextFunction): Promise<void>;
export default internalAuthMiddleware;
